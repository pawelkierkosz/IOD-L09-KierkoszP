zmiana2
# put_io_lab
Pawel Kierkosz
24.10.2024r.
kolejna zmiana
jeszcze jedna zmiana
